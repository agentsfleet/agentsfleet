M256_001 website visual review

Local Chromium renders use sample data.
The before folder shows the M256_001 branch at dd6eade3f.
Each folder holds the same eight routes or states in light and dark at 1440 and 390 pixels.
The measurements record viewport width, document height, and screenshot height.
Full-page images use lossless WebP.
